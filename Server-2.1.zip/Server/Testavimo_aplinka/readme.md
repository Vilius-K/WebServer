sudo systemctl start redis-server
sudo celery -A main.celery worker --loglevel=info
pip3 install eventlet

