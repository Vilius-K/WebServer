from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for, Response
from flask_login import login_required, current_user
from .models import Task, Problems, User, School, Submissions, Lessons
from datetime import datetime, timezone
from . import db
from .submitted_file_queue import compile_code
import pytz
from celery.result import AsyncResult
from datetime import timedelta

views = Blueprint('views', __name__)
Submitted_code_set = set()

defaultDate=datetime(1111, 1, 1, 11, 11, 11)
vilnius_tz = pytz.timezone('Europe/Vilnius')


@views.context_processor
def inject_len():
    return dict(len=len)


def user_school_name():
    if current_user.school_id != 0: return School.query.get(current_user.school_id).name
    else: return ''


def submitted_code_set_remove(user_id, problem_id):
    try: Submitted_code_set.remove((user_id,  problem_id))
    except: pass


def task_is_availible(task):

    if task.openingDate != defaultDate and (task.openingDate <= datetime.now() and task.closingDate > datetime.now()):
        return True
    elif task.openingDate == defaultDate: return True
    else: return False


def lesson_is_availible(lesson):

    if lesson.openingDate != defaultDate and (lesson.openingDate <= datetime.now() and lesson.closingDate > datetime.now()):
        return True
    elif lesson.openingDate == defaultDate: return True
    else: return False



@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    page = request.args.get('page', 1, type=int)
    sort = request.args.get('sort', None)
    start_date = request.args.get('start_date', None)
    end_date = request.args.get('end_date', None)
    search_query = request.args.get('search', '')

    task_query = Task.query.filter(Task.school_id == current_user.school_id)

    if start_date:
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        task_query = task_query.filter(Task.date >= start_date)
    if end_date:
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date() + timedelta(days=1)
        task_query = task_query.filter(Task.date < end_date)


    if sort == 'oldest':
        task_query = task_query.order_by(Task.date.asc())
    elif sort == 'newest':
        task_query = task_query.order_by(Task.date.desc())

    tasks = task_query.paginate(page=page, per_page=10)

    if search_query:
        task_query_all_pages = Task.query.filter(Task.school_id == current_user.school_id)
        task_query_all_pages = task_query_all_pages.filter(Task.name.ilike(f'%{search_query}%'))
        task_ids = [task.id for task in task_query_all_pages.all()]
        tasks = task_query.filter(Task.id.in_(task_ids)).paginate(page=page, per_page=10)

    return render_template(
        'home.html',
        tasks=tasks,
        user=current_user,
        page=page,
        prev_page=page-1,
        next_page=page+1,
        has_next_page=tasks.has_next,
        search_query=search_query,
        start_date=start_date,
        end_date=end_date,
        sort=sort,
        school_name=user_school_name()
    )



@views.route('/pdf/<problem_id>')
@login_required
def pdf(problem_id):

    problem = Problems.query.get(problem_id)

    if problem and problem.school_id == current_user.school_id:
        path = f'/home/platforma/PDF_Salygos/{problem_id}.pdf'
        return send_file(path)
    else:
        return redirect(url_for('views.home'))



@views.route('/task/<task_id>', methods=['GET', 'POST'])
@login_required
def task(task_id):

    task = Task.query.filter_by(id=task_id).first()
    if not task: return redirect(url_for('views.home'))
    problem = Problems.query.get(task.problemsId)

    if request.method == 'POST' and task and task_is_availible(task):

        submitted_code = request.form.get('submitted_code')

        ### Jei vartotojo pateiktas sprendimas yra per ilgas:
        if len(submitted_code) >= 560000:
            flash('Pateiktas sprendimas yra per ilgas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))
        elif len(submitted_code) < 1:
            flash('Pateiktas sprendimas yra per trumpas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))

        ### Vartotojo pateiktas sprendimas yra perduodamas pateiktų sprendimų eilei
        if Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-2).first():
            flash('Vienu metu gali būti pateiktas tik vienas suplanuotas sprendimas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))

        elif Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-3).first():
            flash('Vienu metu gali būti pateiktas tik vienas sprendimas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))

        ### Vartotojo pateiktas sprendimas yra įkeliamas į databazę
        if task.testingDate == defaultDate or task.testingDate <= datetime.now():
            user_submission_status = -3
        else:
            user_submission_status = -2

        new_submission = Submissions(user_id=current_user.id, task_id=task.id, status=user_submission_status, submitted_code=submitted_code)
        db.session.add(new_submission)
        db.session.commit()

        ### Vartotojo sprendimas perduodamas pateiktų sprendimų eilei
        if user_submission_status == -3:
            user_submission = compile_code.delay(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount,
                submitted_code, task.open_test_cases)
        else:
            vilnius_dt = vilnius_tz.localize(task.testingDate)
            user_submission = compile_code.apply_async(args=(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount, submitted_code, task.open_test_cases),
                eta=vilnius_dt.astimezone(pytz.UTC))

        ### Celery ID kodas išsaugomas databazėje
        new_submission.celery_id = user_submission.id
        db.session.commit()

        if user_submission_status == -3:
            flash('Sprendimas gautas ir šiuo metu yra vertinamas.', category='success')
        else:
            flash(f'Sprendimas gautas ir bus vertinamas {task.testingDate}', category='success')

        return redirect(url_for('views.task', task_id=task_id))

    elif not task_is_availible(task):
        flash('Šiuo metu užduotis yra neaktyvi.', category='error')
        return redirect(url_for('views.home'))

    else:
        return render_template('problem.html', problem_id=problem.id, user=current_user, school_name=user_school_name())



@views.route('/submissions')
@login_required
def submissions():
    user_submissions = Submissions.query.filter_by(user_id=current_user.id).all()
    return render_template('submissions.html', user_submissions=user_submissions, user=current_user, school_name=user_school_name())



@views.route('/submissions/view_submission/<submission_id>')
@login_required
def view_submission(submission_id):

    submission = Submissions.query.get(submission_id)
    submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id:
        response = Response(submission.submitted_code, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{submission.task.name}.cpp')
        return response

    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id:
        response = Response(submission.submitted_code, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{submission.task.name}.cpp')
        return response

    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/resubmit/<submission_id>')
@login_required
def resubmit(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission and submission.user_id == current_user.id and submission.status == -1:

        task = Problems.query.get(submission.task_id)

        if task.testingDate == defaultDate or task.testingDate <= datetime.now():
            user_submission = compile_code.delay(current_user.id,  task.problems.id, task.id, task.problems.timeLimit, task.problems.memoryLimit, task.problems.testCount,
                submission.submitted_code, task.open_test_cases)
            submission.status = -3
        
        else:
            vilnius_dt = vilnius_tz.localize(task.testingDate)
            user_submission = compile_code.apply_async(args=(current_user.id,  task.problems.id, task.id, task.problems.timeLimit, task.problems.memoryLimit, task.problems.testCount,
                submission.submitted_code, task.open_test_cases),
                eta=vilnius_dt.astimezone(pytz.UTC))
            submission.status = -2

        db.session.commit()
        return redirect(url_for('views.submissions'))
    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/cancel_submission/<submission_id>')
@login_required
def cancel_submission(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission and submission.user_id == current_user.id and (submission.status == -2 or submission.status == -3):

        result = AsyncResult(submission.celery_id)

        if result.status == 'PENDING':
            result.revoke(terminate=True)
            db.session.delete(submission)
            db.session.commit()
            flash('Sprendimo testavimas buvo atšauktas.', category='success')

        else:
            flash('Sprendimo testavimo atšaukti nepavyko.', category='error')

        return redirect(url_for('views.submissions'))
    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/error/<submission_id>')
@login_required
def submission_error(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission and submission.user_id == current_user.id and submission.status == 2:
        return submission.error_msg
    else:
        return redirect(url_for('views.home'))


@views.route('/submissions/testing_results/<submission_id>')
@login_required
def testing_results(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission: submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id and submission.status == 3:
        return render_template('results.html', results=submission.results, user=current_user, school_name=user_school_name(), task_name=submission.task.name,
            date=submission.date, score=submission.score, test_count=submission.task.problems.testCount, open_test_cases=submission.task.open_test_cases, id=submission.id, task_id=submission.task.id)
    
    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id:
        return render_template('results.html', results=submission.results, user=current_user, school_name=user_school_name(), task_name=submission.task.name,
            date=submission.date, score=submission.score, test_count=submission.task.problems.testCount, open_test_cases=submission.task.open_test_cases, id=submission.id, task_id=submission.task.id)
    
    else:
        return redirect(url_for('views.home'))



@views.route('/task/<task_id>/test_case/<test_case_id>/<test_type>')
@login_required
def test_case_input_output(task_id, test_case_id, test_type):

    task = Task.query.get(task_id)
    task_id = int(task_id)
    test_case_id = int(test_case_id)

    if task and task.school_id == current_user.school_id and test_case_id >= 1 and test_case_id <= task.open_test_cases:

        if test_type == 'IN':
            try: return send_file(f'/home/platforma/Testai/{task_id}/{test_case_id}.in')
            except: return redirect(url_for('views.home'))

        elif test_type == 'SOL':
            try: return send_file(f'/home/platforma/Testai/{task_id}/{test_case_id}.sol')
            except: return redirect(url_for('views.home'))

        else: return redirect(url_for('views.home'))

    else:
        return redirect(url_for('views.home'))



@views.route('/task/<submission_id>/test_case/<test_case_id>')
@login_required
def user_test_case_output(submission_id, test_case_id):

    submission = Submissions.query.get(submission_id)
    submission_id = int(submission_id)
    test_case_id = int(test_case_id)

    if submission: submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id and test_case_id >= 1 and test_case_id <= submission.task.open_test_cases:

        output = submission.output[test_case_id-1]
        response = Response(output, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{test_case_id}.sol')
        return response

    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id and test_case_id >= 1 and test_case_id <= submission.task.open_test_cases:

        output = submission.output[test_case_id-1]
        response = Response(output, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{test_case_id}.sol')
        return response

    else: 
        return redirect(url_for('views.home'))


@views.route('/lessons')
@login_required
def lessons():
    lessons = Lessons.query.filter(Lessons.students.contains(current_user.id)).all()
    return render_template('lessons.html', lessons=lessons, user=current_user, school_name=user_school_name(), defaultDate=defaultDate)


@views.route('/lessons/lesson/<lesson_id>')
@login_required
def lesson(lesson_id):

    lesson = Lessons.query.get(lesson_id)
    if lesson: lesson_students_ids = lesson.students

    if lesson and str(current_user.id) in lesson_students_ids and lesson_is_availible(lesson):
        tasks = Task.query.filter(Task.id.in_(lesson.tasks)).all()
        return render_template('lesson.html', tasks=tasks, lesson=lesson, user=current_user, school_name=user_school_name())
    else: 
        return redirect(url_for('views.home'))


@views.route('/edit_user', methods=['GET', 'POST'])
@login_required
def edit_user():

    if request.method == 'POST':

        user = User.query.get(current_user.id)
        first_last_name = request.form.get('first_last_name')
        email = request.form.get('email')
        user_by_email = User.query.filter_by(email=email).first()

        if user_by_email:
            flash('El. pašto adresas jau panaudotas.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(email) < 4:
            flash('El. pašto adresas turi būti ilgesnis nei 3 simboliai.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(email) > 150:
            flash('El. pašto adresas turi būti trumpesnis nei 150 simbolių.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(first_last_name) < 3:
            flash('Vartotojo vardas ir pavardė turi būti ilgesni nei 3 simboliai.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(first_last_name) > 40:
            flash('Vartotojo vardas ir pavardė būti trumpesni nei 40 simbolių.', category='error')
            return redirect(url_for('views.edit_user'))

        user.first_last_name = first_last_name
        user.email = email
        db.session.commit()
        flash('Varotojo duomenys sėkmingai atnaujinti.', category='success')
        return redirect(url_for('views.edit_user'))

    else:
        return render_template('edit_user.html', user=current_user, school_name=user_school_name())