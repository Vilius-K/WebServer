from celery import Celery
from queue import Queue
import subprocess
import time
import os
import sys

### Testing enviroments config ###
for env_id in range(1, 6):
    sys.path.append(f'/home/server/Testavimo_aplinka/Aplinka{env_id}')

from kompiliatorius1 import Aplinka1
from kompiliatorius2 import Aplinka2
from kompiliatorius3 import Aplinka3
from kompiliatorius4 import Aplinka4
from kompiliatorius5 import Aplinka5

Testing_Environments = {
    1: Aplinka1,
    2: Aplinka2,
    3: Aplinka3,
    4: Aplinka4,
    5: Aplinka5
}

### Celery config ###
app = Celery('submitted_file_queue', broker='redis://localhost:6379/0', backend='redis://localhost:6379/0')
app.conf.task_concurrency = 5

### Queues and sets ###
Submitted_code_set = set()
Availible_testing_environment = Queue()
for env_number in range(1, 6): Availible_testing_environment.put(env_number)


@app.task
def compile_code(user_id, problem_id, time_limit, memory_limit, test_count, submitted_code):

    result_list = []

    ## Jei siuo metu kompiliuojamas kitas vartotojo pateiktas kodas
    if (user_id, problem_id) in Submitted_code_set:
        result_list.append(-1)
        return result_list

    Submitted_code_set.add((user_id, problem_id))
    Environment_id = Availible_testing_environment.get()

    ## Vartotojo pateiktas kodas paverčiamas į cpp programą
    file_path = f'/home/server/Testavimo_aplinka/Aplinka{Environment_id}/programa.cpp'

    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except:
            Submitted_code_set.remove((user_id, problem_id))
            Availible_testing_environment.put(Environment_id)
            result_list.append(0)
            return result_list

    with open(file_path, 'w') as f:
        f.write(submitted_code)

    ## Failas sukompiliuojamas ir paleidžiamas
    try:
        result_list = Testing_Environments[Environment_id](test_count, memory_limit, time_limit, problem_id)
    except:
        Submitted_code_set.remove((user_id, problem_id))
        Availible_testing_environment.put(Environment_id)
        result_list.append(0)
        return result_list

    ## Testavimo aplinka pridedama prie laisvu aplinku saraso
    Submitted_code_set.remove((user_id, problem_id))
    Availible_testing_environment.put(Environment_id)

    ## Gražiname kompiliavimo rezultatus
    return result_list