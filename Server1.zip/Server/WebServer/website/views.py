from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for
from flask_login import login_required, current_user
from .models import Task, Problems, User, School
from datetime import datetime
from . import db
import os
import sys
import random, string
sys.path.append('/home/server/Testavimo_aplinka/')
from submitted_file_queue import compile_code


views = Blueprint('views', __name__)
Submitted_code_set = set()


@views.context_processor
def inject_len():
    return dict(len=len)


def user_school_name():
    if current_user.school_id != 0:
        return School.query.get(current_user.school_id).name
    else:
        return ''


def task_is_availible(task):

    defaultDate=datetime(1111, 1, 1, 11, 11, 11)
    if task.openingDate != defaultDate and (task.openingDate <= datetime.now() and task.closingDate > datetime.now()):
        return True
    elif task.openingDate == defaultDate: return True
    else: return False



@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    school_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
    return render_template("home.html", user=current_user, school_tasks=school_tasks, current_time=datetime.now(), school_name=user_school_name(),
        defaultDate=datetime(1111, 1, 1, 11, 11, 11))


@views.route('/pdf/<problem_id>')
@login_required
def pdf(problem_id):
    path = f'/home/server/PDF_Salygos/{problem_id}.pdf'
    return send_file(path)


@views.route('/task/<task_id>', methods=['GET', 'POST'])
@login_required
def task(task_id):

    task = Task.query.filter_by(id=task_id).first()
    if not task: return redirect(url_for('views.home'))

    problem = Problems.query.get(task.problemsId)
    problem_id = problem.id

    if (request.method == 'POST' and task and task_is_availible(task) and not (current_user.id, problem_id) in Submitted_code_set):

        Submitted_code_set.add((current_user.id, problem_id))
        submitted_code = request.form.get('submitted_code')
        result_list = compile_code(current_user.id, problem_id, problem.timeLimit, problem.memoryLimit, problem.testCount, submitted_code)
        Submitted_code_set.remove((current_user.id, problem_id))

        if result_list[0] == -1:
            flash('Šiuo metu testuojamas kitas pateiktas kodas šiam uždaviniui.', category='error')
            return redirect(url_for('views.task'))
        elif result_list[0] == 0:
            flash('Testavimo klaida. Susisiekite su mokyklos administratoriumi.', category='error')
            return redirect(url_for('views.task'))
        
        return render_template('output.html', result_list=result_list, user=current_user, school_name=user_school_name())

    elif (current_user.id, problem_id) in Submitted_code_set:
        flash('Šiuo metu testuojamas kitas pateiktas kodas šiam uždaviniui.', category='error')
        return redirect(url_for('views.task'))
    elif not task_is_availible(task):
        flash('Šiuo metu užduotis yra neaktyvi.', category='error')
        return redirect(url_for('views.home'))
    else:
        return render_template('problem.html', problem_id=problem_id, user=current_user, school_name=user_school_name())



@views.route('/admin/users')
@login_required
def users():

    if current_user.urole == "SERVER-ADMIN":
        school_name = user_school_name()
        return render_template("users.html", user=current_user, user_list=User.query.all(), school_name=school_name)
    else:
        return redirect(url_for('views.home'))



@views.route('/admin/delete_user', methods=['POST'])
@login_required
def delete_user():
    if current_user.urole == "SERVER-ADMIN":
        delete_user_id = request.form.get('user_id')
        delete_user = User.query.get(delete_user_id)
        db.session.delete(delete_user)
        db.session.commit()
        return redirect(url_for('views.users'))
    else:
        return redirect(url_for('views.home'))



@views.route('/admin/users/<user_id>', methods=['GET', 'POST'])
@login_required
def user(user_id):

    user = User.query.get(user_id)

    if current_user.urole == "SERVER-ADMIN" and request.method == 'POST' and user:

        user.email = request.form.get('email')
        user.first_name = request.form.get('first_name')
        user.school_id = request.form.get('school_id')
        user.urole = request.form.get('urole')
        db.session.commit()
        return redirect(url_for('views.users'))

    elif current_user.urole == "SERVER-ADMIN" and request.method == 'GET' and user:
        school_name = user_school_name()
        return render_template("user.html", user=current_user, editing_user=user, school_name=school_name)
    else:
        return redirect(url_for('views.home'))



@views.route('/admin/schools')
@login_required
def schools():

    if current_user.urole == "SERVER-ADMIN":
        return render_template("schools.html", user=current_user, school_list=School.query.all(), school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@views.route('/admin/schools/<school_id>', methods=['GET', 'POST'])
@login_required
def school(school_id):

    school = School.query.get(school_id)

    if current_user.urole == "SERVER-ADMIN" and request.method == 'POST' and school:

        school.name = request.form.get('name')
        school.owner_id = request.form.get('owner_id')
        school.problem_limit = request.form.get('problem_limit')
        school.task_limit = request.form.get('task_limit')
        school.invitation_code = request.form.get('invitation_code')
        db.session.commit()
        return redirect(url_for('views.schools'))

    elif current_user.urole == "SERVER-ADMIN" and request.method == 'GET' and school:
        school_name = user_school_name()
        return render_template("school.html", user=current_user, school=school, school_name=school_name)
    else:
        return redirect(url_for('views.home'))



@views.route('/admin/delete_school', methods=['POST'])
@login_required
def delete_school():
    if current_user.urole == "SERVER-ADMIN":
        delete_school_id = request.form.get('school_id')
        delete_school = School.query.get(delete_school_id)
        db.session.delete(delete_school)
        db.session.commit()
        return redirect(url_for('views.schools'))
    else:
        return redirect(url_for('views.home'))



@views.route('/admin/new-school', methods=['GET', 'POST'])
@login_required
def new_school():

    if request.method == 'POST' and current_user.urole == "SERVER-ADMIN":
        
        ## Reikiama informacija apie naują mokyklą
        school_name = request.form.get('school_name')
        problem_limit = request.form.get('problem_limit')
        task_limit = request.form.get('task_limit')
        owner_id = request.form.get('owner_id')
        availible_until_str = request.form.get('availible_until')
        availible_until = datetime.strptime(availible_until_str, '%Y-%m-%dT%H:%M')

        ## Sukuriame mokyklos pakvietimo kodą
        letters = string.ascii_lowercase
        invitation_code = ''.join(random.choice(letters) for i in range(10))
        while School.query.filter_by(invitation_code=invitation_code).first():
            invitation_code = ''.join(random.choice(letters) for i in range(10))
        
        print('Prisijungimo kodas:', invitation_code)

        ## Į databazę įkeliame informaciją apie naują mokyklą
        new_school = School(name=school_name, problem_limit=problem_limit, task_limit=task_limit, owner_id=owner_id, availible_until=availible_until,
            invitation_code=invitation_code)
        db.session.add(new_school)
        db.session.commit()

        flash('Nauja mokykla sukurta sėkmingai.', category='success')
        return redirect(url_for('views.home'))

    elif request.method == 'GET' and current_user.urole == "SERVER-ADMIN":
        school_name = user_school_name()
        return render_template("new-school.html", user=current_user, school_name=school_name)
    else:
        return redirect(url_for('views.home'))



@views.route('/new-problem', methods=['GET', 'POST'])
@login_required
def new_problem():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        ## Reikiama informacija apie uždavinį
        taskName = request.form.get('taskName')
        timeLimit = request.form.get('timeLimit')
        memoryLimit = request.form.get('memoryLimit')
        pdf_file = request.files.get('PDF')
        test_files = request.files.getlist("tests")

        if int(timeLimit) > 5 or int(timeLimit) < 1:
            flash('Laiko limitas galimas iki 5 sekundžių.', category='error')
            return redirect(url_for('views.new_task'))
        elif int(memoryLimit) > 500 or int(memoryLimit) < 1:
            flash('Laiko limitas galimas iki 500 mb.', category='error')
            return redirect(url_for('views.new_task'))
        elif len(taskName) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
            return redirect(url_for('views.new_task'))
        else:

            ## Į databazę įkeliame informaciją apie sukurtą užduotį
            new_problem = Problems(name=taskName, timeLimit=timeLimit, memoryLimit=memoryLimit, testCount=len(test_files)/2,
                school_id=current_user.school_id)
            db.session.add(new_problem)
            db.session.commit()
            
            ## Serveryje išsaugome uždavinio PDF sąlygą
            pdfName = str(new_problem.id) + '.pdf'
            pdf_file.save('/home/server/PDF_Salygos/' + pdfName)

            test_files = sorted(test_files, key=lambda x: x.filename)
            os.makedirs(os.path.join('/home/server/Testai/', str(new_problem.id)))

            ## Serveryje išsaugome uždavinio testus
            EXTENSION_IN = True
            test_case_id = 1
            for test_file in test_files:

                if EXTENSION_IN:
                    test_case_name = str(test_case_id) + '.in'
                    test_file.save(os.path.join('/home/server/Testai/', str(new_problem.id), test_case_name))
                    EXTENSION_IN = False
                else:
                    test_case_name = str(test_case_id) + '.sol'
                    test_file.save(os.path.join('/home/server/Testai/', str(new_problem.id), test_case_name))
                    EXTENSION_IN = True
                    test_case_id += 1
            
            ## Jei nauja užduotis sukurta sėkmingai
            flash('Naujas uždavinys sukurtas sėkmingai!', category='success')
            return redirect(url_for('views.home'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        school_name = user_school_name()
        return render_template("new-problem.html", user=current_user, school_name=school_name)
    else:
        return redirect(url_for('views.home'))




@views.route('/new-task', methods=['GET', 'POST'])
@login_required
def new_task():
    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        problems = Problems.query.all()
        selected_problem_id = request.form.get('selectedProblemId')
        taskName = request.form.get('taskName')
        opening_date_str = request.form.get('openingDate')
        closing_date_str = request.form.get('closingDate')

        if not selected_problem_id:
            flash('Būtina pasirinkti uždavinį.', category='error')
            return render_template("new-task.html", user=current_user, problems=problems)

        selected_problem = Problems.query.get(selected_problem_id)

        if not selected_problem:
            flash('Ieškomas uždavinys neegzistuoja.', category='error')
            return render_template("new-task.html", user=current_user, problems=problems)

        if not taskName:
            flash('Būtina sukurti užduoties pavadinimą.', category='error')
            return render_template("new-task.html", user=current_user, problems=problems)

        if opening_date_str == '':
            openingDate = datetime(1111, 1, 1, 11, 11, 11)
        else:
            openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')

        if closing_date_str == '':
            closingDate = datetime(1111, 1, 1, 11, 11, 11)
        else:
            closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

        if opening_date_str != '' and openingDate.year < datetime.now().year:
            flash('Netinkama užduoties atidarymo data.', category='error')
            return render_template("new-task.html", user=current_user, problems=problems)
        elif closing_date_str != '' and closingDate < datetime.now():
            flash('Netinkama užduoties uždarymo data.', category='error')
            return render_template("new-task.html", user=current_user, problems=problems)
        else:
            new_task = Task(
                problemsId=selected_problem.id,
                name=taskName,
                openingDate=openingDate,
                closingDate=closingDate,
                school_id=current_user.school_id
            )
            db.session.add(new_task)
            db.session.commit()

            flash('Nauja užduotis sukurta sėkmingai!', category='success')
            return redirect(url_for('views.home'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        problems = Problems.query.all()
        return render_template("new-task.html", user=current_user, problems=problems, school_name=user_school_name())

    else:
        return redirect(url_for('views.home'))



@views.route('/school-admin/problems')
@login_required
def problems():

    if current_user.urole == "SCHOOL-ADMIN":
        school_problems = Problems.query.filter_by(school_id=current_user.school_id).all()
        return render_template("problems.html", user=current_user, school_problems=school_problems, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@views.route('/school-admin/problems/<problem_id>', methods=['GET', 'POST'])
@login_required
def edit_problem(problem_id):

    problem = Problems.query.get(problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST' and problem:

        problem.name = request.form.get('name')
        problem.timeLimit = request.form.get('timeLimit')
        problem.memoryLimit = request.form.get('memoryLimit')
        db.session.commit()
        return redirect(url_for('views.problems'))
        
    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET' and problem:
        return render_template("problem.html", user=current_user, problem=problem, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@views.route('/school-admin/delete_problem', methods=['POST'])
@login_required
def delete_problem():
    if current_user.urole == "SCHOOL-ADMIN":
        delete_problem_id = request.form.get('problem_id')
        delete_problem = Problems.query.get(delete_problem_id)
        db.session.delete(delete_problem)
        db.session.commit()
        return redirect(url_for('views.problems'))
    else:
        return redirect(url_for('views.home'))



# @views.route('/school-admin/tasks')
# @login_required
# def tasks():

#     if current_user.urole == "SCHOOL-ADMIN":
#         school_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
#         return render_template("tasks.html", user=current_user, school_tasks=school_tasks, school_name=user_school_name())
#     else:
#         return redirect(url_for('views.home'))



# @views.route('/school-admin/tasks/<task_id>', methods=['GET', 'POST'])
# @login_required
# def edit_task():

#     if current_user.urole == "SCHOOL-ADMIN":
#         school_problems = Problems.query.filter_by(school_id=current_user.school_id).first()
#         return render_template("problems.html", user=current_user, school_problems=school_problems, school_name=user_school_name())
#     else:
#         return redirect(url_for('views.home'))



# @views.route('/school-admin/delete_task', methods=['POST'])
# @login_required
# def delete_task():
#     if current_user.urole == "SCHOOL-ADMIN":
#         delete_task_id = request.form.get('task_id')
#         delete_task = Task.query.get(delete_task_id)
#         db.session.delete(delete_task)
#         db.session.commit()
#         return redirect(url_for('views.tasks'))
#     else:
#         return redirect(url_for('views.home'))