from . import db
from flask_login import UserMixin
from sqlalchemy import DateTime
from datetime import datetime
from sqlalchemy.sql import func

class Problems(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    timeLimit = db.Column(db.Integer)
    memoryLimit = db.Column(db.Integer)
    testCount = db.Column(db.Integer)
    school_id = db.Column(db.Integer)

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    problemsId = db.Column(db.Integer)
    name = db.Column(db.String(100))
    openingDate = db.Column(DateTime, default=datetime.utcnow)
    closingDate = db.Column(DateTime, default=datetime.utcnow)
    school_id = db.Column(db.Integer)

class School(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    owner_id = db.Column(db.Integer)
    problem_limit = db.Column(db.Integer)
    task_limit = db.Column(db.Integer)
    invitation_code = db.Column(db.String(100), unique=True)
    availible_until = db.Column(DateTime)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    urole = db.Column(db.String(20), default='GENERAL')
    school_id = db.Column(db.Integer, default=0)