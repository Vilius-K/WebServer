import subprocess
import resource
import os
import sys

## Rezultatų kodai: 1 (Laiko limitas), 2 (Atminties limitas), 3 (Nesikompiliuoja), 4 (Nenumatyta klaida), 5 (Rezultatai tinka), 6 (Rezultatai netinka)

def cpp_kompiliatorius(env_path):

    programa_path = os.path.join(env_path, 'programa')
    programa_cpp_path = os.path.join(env_path, 'programa.cpp')
    kompiliuok_cmd = ['g++', '-o', programa_path, programa_cpp_path]

    try:
        subprocess.check_output(kompiliuok_cmd, stderr=subprocess.STDOUT)
        return True  # Kompiliavimas pavyko
    except subprocess.CalledProcessError as e:
        error_msg = e.output.decode()
        return False  # Kompiliavimas nepavyko


def paleisk_programa(duomenu_failas, env_path):

    ## paleisk_programa() grazina dvi reiksmes - rezultata ir klaidos koda
    paleisk_cmd = [env_path + 'programa']
    try:
        with open(duomenu_failas) as f: duomenu_failas = f.read()
        rezultatai = subprocess.check_output(paleisk_cmd, input=duomenu_failas.encode(), stderr=subprocess.STDOUT)
        return rezultatai.decode(), 0
    except subprocess.CalledProcessError: return '', 1
    except MemoryError: return '', 2
    except: return '', 4


def palygink_rezultatus(rezultatai, rezultatu_failas):
    # Graziname TRUE, jei programos ir oficialus rezultatai sutampa
    with open(rezultatu_failas) as f:
        rezultatu_duomenys = f.read()
    return rezultatai.strip() == rezultatu_duomenys.strip()


def Aplinka4(Testu_sk, Atminties_limitas, Laiko_limtas, Uzdavinio_id):

    rezultatu_lentele = []
    Atminties_limitas = Atminties_limitas * 1048576
    env_path = '/home/server/Testavimo_aplinka/Aplinka4/'

    ## Kompiliuojame C++ programa
    if not cpp_kompiliatorius(env_path):
        os.remove(os.path.join(env_path, 'programa.cpp'))
        rezultatu_lentele.append(3)
        return rezultatu_lentele

    ## Nustatome laiko bei atminties limitus
    resource.setrlimit(resource.RLIMIT_CPU, (Laiko_limtas, Laiko_limtas))
    resource.setrlimit(resource.RLIMIT_AS, (Atminties_limitas, Atminties_limitas))

    ## Jei programa kompiliuojasi, paleidziame programa
    for Testo_id in range(1, Testu_sk+1):

        duomenu_failas = f'/home/server/Testai/{Uzdavinio_id}/{Testo_id}.in'
        rezultatu_failas = f'/home/server/Testai/{Uzdavinio_id}/{Testo_id}.sol'

        # Paleidziame programa su testo duomenimis
        rezultatai, klaidos_kodas = paleisk_programa(duomenu_failas, env_path)
        
        # Jei programos paleidimo metu atsirado klaidu
        if klaidos_kodas != 0: rezultatu_lentele.append(klaidos_kodas)

        # Palyginame rezultatus su oficialiais rezultatais
        elif palygink_rezultatus(rezultatai, rezultatu_failas): rezultatu_lentele.append(5)
        else: rezultatu_lentele.append(6)

    ## Istriname nereikalingus failus
    os.remove(os.path.join(env_path, 'programa'))
    os.remove(os.path.join(env_path, 'programa.cpp'))

    ## Gražiname testavimo rezultatus
    return rezultatu_lentele
