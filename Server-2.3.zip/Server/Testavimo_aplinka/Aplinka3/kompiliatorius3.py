import subprocess
import resource
import os
import sys
import psutil

## Rezultatų kodai: 1 (Laiko limitas), 2 (Atminties limitas), 3 (Rezultatas tinka), 4 (Rezultatas netinka), 5 (Testavimo klaida)

def laiko_ir_atminties_limitas(Laiko_limtas, Atminties_limitas):
    ## Nustatome laiko bei atminties limitus
    resource.setrlimit(resource.RLIMIT_CPU, (Laiko_limtas, Laiko_limtas))
    resource.setrlimit(resource.RLIMIT_AS, (Atminties_limitas, Atminties_limitas))

def cpp_kompiliatorius(env_path):

    programa_path = os.path.join(env_path, 'programa')
    programa_cpp_path = os.path.join(env_path, 'programa.cpp')
    kompiliuok_cmd = ['g++', '-o', programa_path, programa_cpp_path]

    try:
        subprocess.check_output(kompiliuok_cmd, stderr=subprocess.STDOUT)
        return True, ''  # Kompiliavimas pavyko
    except subprocess.CalledProcessError as e:
        error_msg = e.output.decode()
        return False, error_msg # Kompiliavimas nepavyko


def paleisk_programa(duomenu_failas, env_path, Laiko_limtas, Atminties_limitas):

    paleisk_cmd = [env_path + 'programa']

    try:
        with open(duomenu_failas) as f: duomenu_failas = f.read()
        rezultatai = subprocess.check_output(paleisk_cmd, input=duomenu_failas.encode(), stderr=subprocess.STDOUT, preexec_fn=laiko_ir_atminties_limitas(Laiko_limtas, Atminties_limitas))
        return rezultatai.decode(), 0
    except subprocess.CalledProcessError: return '', 1
    except MemoryError: return '', 2
    except: return '', 5


def palygink_rezultatus(rezultatai, rezultatu_failas):
    # Graziname TRUE, jei programos ir oficialus rezultatai sutampa
    with open(rezultatu_failas) as f:
        rezultatu_duomenys = f.read()
    return rezultatai.strip() == rezultatu_duomenys.strip()


def Aplinka3(Testu_sk, Atminties_limitas, Laiko_limtas, Uzdavinio_id, open_test_cases):

    rezultatu_lentele = []
    programos_rezultatai = []

    Ivertinimas = 0
    Atminties_limitas = Atminties_limitas * 1048576
    env_path = '/home/platforma/Testavimo_aplinka/Aplinka3/'

    ## Kompiliuojame C++ programa
    kompiliavimas = cpp_kompiliatorius(env_path)
    if kompiliavimas[0] == False:
        os.remove(os.path.join(env_path, 'programa.cpp'))
        return rezultatu_lentele, 2, 0, kompiliavimas[1], programos_rezultatai

    ## Jei programa kompiliuojasi, paleidziame programa
    for Testo_id in range(1, Testu_sk+1):

        duomenu_failas = f'/home/platforma/Testai/{Uzdavinio_id}/{Testo_id}.in'
        rezultatu_failas = f'/home/platforma/Testai/{Uzdavinio_id}/{Testo_id}.sol'

        # Paleidziame programa su testo duomenimis
        rezultatai, klaidos_kodas = paleisk_programa(duomenu_failas, env_path, Laiko_limtas, Atminties_limitas)
        
        # Jei programos paleidimo metu atsirado klaidu
        if klaidos_kodas != 0: rezultatu_lentele.append(klaidos_kodas)

        # Palyginame rezultatus su oficialiais rezultatais
        elif palygink_rezultatus(rezultatai, rezultatu_failas):
            Ivertinimas += 1
            rezultatu_lentele.append(3)
        else:
            rezultatu_lentele.append(4)

        # Jei nustatyta, išsaugomi programos spausdinami rezultatai
        if Testo_id <= open_test_cases:
            if len(rezultatai) > 1000: rezultatai = rezultatai[:1000] + "..."
            programos_rezultatai.append(rezultatai)

    ## Atstatome laiko ir atminties limitus
    resource.setrlimit(resource.RLIMIT_CPU, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
    resource.setrlimit(resource.RLIMIT_AS, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))

    ## Istriname nereikalingus failus
    os.remove(os.path.join(env_path, 'programa'))
    os.remove(os.path.join(env_path, 'programa.cpp'))

    ## Gražiname testavimo rezultatus
    return rezultatu_lentele, 3, Ivertinimas, '', programos_rezultatai
