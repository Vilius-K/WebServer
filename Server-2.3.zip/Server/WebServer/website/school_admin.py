from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for
from flask_login import login_required, current_user
from .models import Task, Problems, User, School, Submissions, NewGroup, Lessons
from datetime import datetime, timedelta
from . import db
import os
import shutil
from threading import Thread, Lock

### Blueprint config ###
school_admin = Blueprint('school_admin', __name__)
lock = Lock()

defaultDate=datetime(1111, 1, 1, 11, 11, 11)

@school_admin.context_processor
def inject_len():
    return dict(len=len)

def user_school_name():
    if current_user.school_id != 0: return School.query.get(current_user.school_id).name
    else: return ''


@school_admin.route('/school_admin/new_problem', methods=['GET', 'POST'])
@login_required
def new_problem():

    ## Patikriname, ar neviršytas sukurtų uždavinių limitas
    school = School.query.get(current_user.school_id)
    if current_user.urole == "SCHOOL-ADMIN" and school.created_problems == school.problem_limit and request.method == 'POST':
        flash('Viršytas sukurtų uždavinių limitas.', category='error')
        return redirect(url_for('school_admin.new_problem'))

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':
        # Reikiama informacija apie uždavinį
        taskName = request.form.get('taskName')
        timeLimit = request.form.get('timeLimit')
        memoryLimit = request.form.get('memoryLimit')
        pdf_file = request.files.get('PDF')
        test_files = request.files.getlist("tests")

        if timeLimit != None and (int(timeLimit) > 5 or int(timeLimit) < 1):
            flash('Laiko limitas galimas iki 5 sekundžių.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif memoryLimit != None and (int(memoryLimit) > 500 or int(memoryLimit) < 10):
            flash('Atminties limitas galimas nuo 10 iki 500 mb.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif len(taskName) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif len(taskName) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        else:
            if timeLimit == None:
                timeLimit = 1
            if memoryLimit == None:
                memoryLimit = 64

            # Serveris tikrina ar geras PDF formatas
            if pdf_file:
                pdf_extension = os.path.splitext(pdf_file.filename)[1].lower()
                if pdf_extension != ".pdf":
                    flash('Nepalaikomas PDF failo formatas. Prašome pasirinkti .pdf failą.', category='error')
                    return redirect(url_for('school_admin.new_problem'))

            # Serveris tikrina ar geras testu formatas
            IN_FILES = 0
            SOL_FILES = 0

            for test_file in test_files:

                test_extension = os.path.splitext(test_file.filename)[1].lower()

                if test_extension in [".in"]:
                    IN_FILES += 1
                elif test_extension in [".sol"]:
                    SOL_FILES += 1
                else:
                    flash('Nepalaikomas testų failo formatas. Prašome pasirinkti .in ir .sol failus.', category='error')
                    return redirect(url_for('school_admin.new_problem'))

            # Patikriname, ar tinkamas testų skaičius
            if len(test_files) % 2 != 0:
                flash('Pateiktų testų skaičius turi būti lyginis.', category='error')
                return redirect(url_for('school_admin.new_problem'))

            # Patikriname, ar IN ir SOL failų skaičius lygus
            if IN_FILES != SOL_FILES:
                flash('Duomenų ir rezultatų failų skaičius turi būti lygus.', category='error')
                return redirect(url_for('school_admin.new_problem'))

            # Patikriname, ar neviršytas sukurtų testų limitas
            if len(test_files) >= 400:
                flash('Testų failų skaičius privalo būti mažesnis nei 400.', category='error')
                return redirect(url_for('school_admin.new_problem'))

            # Į databazę įkeliame informaciją apie sukurtą užduotį
            new_problem = Problems(
                name=taskName,
                timeLimit=timeLimit,
                memoryLimit=memoryLimit,
                testCount=len(test_files) / 2,
                school_id=current_user.school_id
            )
            db.session.add(new_problem)
            db.session.commit()

            # Atnaujiname sukurtų uždavinių skaičių
            school.created_problems = school.created_problems + 1
            db.session.commit()

            # Serveryje išsaugome uždavinio PDF sąlygą
            pdfName = str(new_problem.id) + '.pdf'
            pdf_file.save('/home/platforma/PDF_Salygos/' + pdfName)

            test_files = sorted(test_files, key=lambda x: x.filename)
            os.makedirs(os.path.join('/home/platforma/Testai/', str(new_problem.id)))

            # Serveryje išsaugome uždavinio testus
            EXTENSION_IN = True
            test_case_id = 1
            for test_file in test_files:
                if EXTENSION_IN:
                    test_case_name = str(test_case_id) + '.in'
                    test_file.save(os.path.join('/home/platforma/Testai/', str(new_problem.id), test_case_name))
                    EXTENSION_IN = False
                else:
                    test_case_name = str(test_case_id) + '.sol'
                    test_file.save(os.path.join('/home/platforma/Testai/', str(new_problem.id), test_case_name))
                    EXTENSION_IN = True
                    test_case_id += 1

            # Jei nauja užduotis sukurta sėkmingai
            flash('Naujas uždavinys sukurtas sėkmingai!', category='success')
            return redirect(url_for('school_admin.new_problem'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        return render_template("new-problem.html", user=current_user, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/new_task', methods=['GET', 'POST'])
@login_required
def new_task():

    ## Patikriname, ar neviršytas sukurtų užduočių limitas
    school = School.query.get(current_user.school_id)
    if current_user.urole == "SCHOOL-ADMIN" and school.created_tasks == school.task_limit and request.method == 'POST':
        flash('Viršytas sukurtų užduočių limitas.', category='error')
        return redirect(url_for('school_admin.new_task'))

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        problems = Problems.query.all()
        selected_problem_id = request.form.get('selectedProblemId')
        taskName = request.form.get('taskName')
        opening_date_str = request.form.get('openingDate')
        closing_date_str = request.form.get('closingDate')
        testing_date_str = request.form.get('testingDate')
        open_test_cases = request.form.get('OpenTestCases')

        if open_test_cases == '': open_test_cases = 0
        else: open_test_cases = int(open_test_cases)

        if not selected_problem_id:
            flash('Būtina pasirinkti uždavinį.', category='error')
            return redirect(url_for('school_admin.new_task'))

        selected_problem = Problems.query.get(selected_problem_id)

        ## Patikriname, ar egzistuoja ieškomas uždavinys
        if not selected_problem:
            flash('Ieškomas uždavinys neegzistuoja.', category='error')
            return redirect(url_for('school_admin.new_task'))

        ## Patikriname, ar teisingai pasirinktos grupės
        if request.form.get('groupCheckbox'):

            selected_groups = request.form.getlist('groupSelect[]')
            
            for group_id in selected_groups:
                group = NewGroup.query.get(group_id)
                if not group or group.school_id != current_user.school_id:
                    flash('Neteisingai pasiriktos grupės.', category='error')
                    return redirect(url_for('school_admin.new_task'))
        
        else:
            selected_groups = []


        ## Patikriname, ar teisingai užpildyti puslapio laukeliai
        if open_test_cases != 0 and (open_test_cases < 1 or open_test_cases > selected_problem.testCount):
            flash('Neteisingai pasirinkti atvirieji testai.', category='error')
            return redirect(url_for('school_admin.new_task'))

        if not taskName:
            flash('Būtina sukurti užduoties pavadinimą.', category='error')
            return redirect(url_for('school_admin.new_task'))
        
        if len(taskName) > 50:
            flash('Per ilgas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_task'))

        if len(taskName) < 1:
            flash('Per trumpas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_task'))

        if opening_date_str == '': openingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')

        if closing_date_str == '': closingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

        if testing_date_str == '': testingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: testingDate = datetime.strptime(testing_date_str, '%Y-%m-%dT%H:%M')

        if opening_date_str != '' and openingDate.year < datetime.now().year:
            flash('Netinkama užduoties atidarymo data.', category='error')
            return redirect(url_for('school_admin.new_task'))
        elif closing_date_str != '' and closingDate < datetime.now():
            flash('Netinkama užduoties uždarymo data.', category='error')
            return redirect(url_for('school_admin.new_task'))
        elif testing_date_str != '' and testingDate < datetime.now():
            flash('Netinkama užduoties testavimo data.', category='error')
            return redirect(url_for('school_admin.new_task'))
        else:
            new_task = Task(
                problemsId=selected_problem.id,
                name=taskName,
                openingDate=openingDate,
                closingDate=closingDate,
                testingDate=testingDate,
                school_id=current_user.school_id,
                open_test_cases=open_test_cases,
                groups=selected_groups
            )
            db.session.add(new_task)
            db.session.commit()

            # Atnaujiname sukurtų užduočių skaičių
            school.created_tasks = school.created_tasks + 1
            db.session.commit()

            flash('Nauja užduotis sukurta sėkmingai!', category='success')
            return redirect(url_for('school_admin.new_task'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        problems = Problems.query.all()
        return render_template("new-task.html", user=current_user, problems=problems, school_name=user_school_name(), groups=NewGroup.query.all())

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/problems')
@login_required
def problems():

    if current_user.urole == "SCHOOL-ADMIN":
        school_problems = Problems.query.filter_by(school_id=current_user.school_id).all()
        return render_template("problems.html", user=current_user, school_problems=school_problems, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/problems/<problem_id>', methods=['GET', 'POST'])
@login_required
def edit_problem(problem_id):

    problem = Problems.query.get(problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST' and problem:
        name = request.form.get('name')
        timeLimit = request.form.get('timeLimit')
        memoryLimit = request.form.get('memoryLimit')
        school_problems = Problems.query.filter_by(school_id=current_user.school_id).all()

        if timeLimit != None and (int(timeLimit) > 5 or int(timeLimit) < 1):
            flash('Laiko limitas galimas iki 5 sekundžių.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        elif memoryLimit != None and (int(memoryLimit) > 500 or int(memoryLimit) < 10):
            flash('Atminties limitas galimas nuo 10 iki 500 MB.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        elif len(name) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        elif len(name) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        else:
            problem.name = name
            problem.timeLimit = timeLimit
            problem.memoryLimit = memoryLimit
            db.session.commit()
            flash('Uždavinys sėkmingai atnaujintas.', category='success')
            return redirect(url_for('school_admin.problems'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET' and problem:
        return render_template("edit_problem.html", user=current_user, problem=problem, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_problem', methods=['POST'])
@login_required
def delete_problem():

    lock.acquire()
    delete_problem_id = request.form.get('problem_id')
    delete_problem = Problems.query.get(delete_problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and delete_problem and not Task.query.filter_by(problemsId=delete_problem_id).first():

        db.session.delete(delete_problem)
        db.session.commit()

        # Atnaujiname sukurtų uždavinių skaičių
        school = School.query.get(current_user.school_id)
        school.created_problems = school.created_problems - 1
        db.session.commit()

        shutil.rmtree(f'/home/platforma/Testai/{delete_problem_id}/')
        os.remove(f'/home/platforma/PDF_Salygos/{delete_problem_id}.pdf')

        lock.release()
        flash('Uždavinys sėkmingai ištrintas.', category='success')
        return redirect(url_for('school_admin.problems'))

    elif Task.query.filter_by(problemsId=delete_problem_id).first():
        lock.release()
        flash('Šis uždavinys yra naudojamas užduotyje, todėl uždavinio ištrinti negalima.', category='error')
        return redirect(url_for('school_admin.delete_problem'))
    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/tasks')
@login_required
def tasks():

    if current_user.urole == "SCHOOL-ADMIN":
        school_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        return render_template("tasks.html", user=current_user, school_tasks=school_tasks, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/tasks/<task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    task = Task.query.get(task_id)

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST' and task:
        name = request.form.get('name')
        opening_date_str = request.form.get('openingDate')
        closing_date_str = request.form.get('closingDate')

        if len(name) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
        elif len(name) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
        else:

            if opening_date_str == '':
                openingDate = datetime(1111, 1, 1, 11, 11, 11)
            else:
                openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')

            if closing_date_str == '':
                closingDate = datetime(1111, 1, 1, 11, 11, 11)
            else:
                closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

            current_datetime = datetime.now()
            if opening_date_str != '' and (openingDate.year < current_datetime.year or
                                           openingDate > current_datetime + timedelta(days=365)):
                flash('Netinkama užduoties atidarymo data.', category='error')
            elif closing_date_str != '' and (closingDate < current_datetime or
                                              closingDate > current_datetime + timedelta(days=365) or
                                              closingDate < openingDate):
                flash('Netinkama užduoties uždarymo data.', category='error')
            else:
                task.name = name
                task.openingDate = openingDate
                task.closingDate = closingDate
                db.session.commit()
                return redirect(url_for('school_admin.tasks'))

        return render_template("edit_task.html", user=current_user, task=task, school_name=user_school_name(),
                               openingDate_default=(task.openingDate == datetime(1111, 1, 1, 11, 11, 11)),
                               closingDate_default=(task.closingDate == datetime(1111, 1, 1, 11, 11, 11)))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET' and task:
        return render_template("edit_task.html", user=current_user, task=task, school_name=user_school_name(),
                               openingDate_default=(task.openingDate == datetime(1111, 1, 1, 11, 11, 11)),
                               closingDate_default=(task.closingDate == datetime(1111, 1, 1, 11, 11, 11)))
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_task', methods=['POST'])
@login_required
def delete_task():

    delete_task_id = request.form.get('task_id')
    lock.acquire()
    delete_task = Task.query.get(delete_task_id)
    if delete_task: lessons = Lessons.query.filter(Lessons.tasks.contains(delete_task.id)).all()

    if current_user.urole == "SCHOOL-ADMIN" and delete_task and not lessons:

        db.session.delete(delete_task)
        db.session.commit()

        # Atnaujiname sukurtų užduočių skaičių
        school = School.query.get(current_user.school_id)
        school.created_tasks = school.created_tasks - 1
        db.session.commit()

        lock.release()
        return redirect(url_for('school_admin.tasks'))
    elif lessons:
        lock.release()
        flash('Ši užduotis naudojama pamokoje, todėl jos ištrinti negalima.', category='error')
        return redirect(url_for('school_admin.delete_task'))
    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/school_users')
@login_required
def school_users():
    if current_user.urole == "SCHOOL-ADMIN":
        school_users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        invitation_code = School.query.get(current_user.school_id).invitation_code
        return render_template("school_users.html", user=current_user, school_users=school_users, school_name=user_school_name(), invitation_code=invitation_code)
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_user/<user_id>', methods=['POST'])
@login_required
def delete_school_user(user_id):

    lock.acquire()
    user = User.query.get(user_id)
    if user: user_groups = NewGroup.query.filter(user.id.in_(NewGroup.students)).all()
    if user: user_lessons = Lessons.query.filter(user.id.in_(Lessons.students)).all()

    if current_user.urole == "SCHOOL-ADMIN" and user and user.school_id == current_user.school_id and user.urole == "GENERAL" and user_groups:
        lock.release()
        flash('Mokinys pridėtas prie grupės, todėl jo ištrinti negalima.', category='error')
        return redirect(url_for('school_admin.school_users'))

    elif current_user.urole == "SCHOOL-ADMIN" and user and user.school_id == current_user.school_id and user.urole == "GENERAL" and user_lessons:
        lock.release()
        flash('Mokinys pridėtas prie pamokos, todėl jo ištrinti negalima.', category='error')
        return redirect(url_for('school_admin.school_users'))

    elif current_user.urole == "SCHOOL-ADMIN" and user and user.school_id == current_user.school_id and user.urole == "GENERAL" and not user_groups and not user_lessons:
        user.school_id = 0
        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.school_users'))

    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/new-group', methods=['GET', 'POST'])
@login_required
def new_group():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':
        group_name = request.form.get('groupName')
        selected_student_ids = request.form.get('selectedStudentId')
        student_ids_list = list(selected_student_ids)
        student_ids_list = list(set(student_ids_list))
        student_ids_list = [x for x in student_ids_list if x.isdigit()]

        ## Patikriname, ar visi pasirinkti vartotojai egzistuoja
        for student_id in student_ids_list:
            user = User.query.get(student_id)
            if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
                flash('Blogai pasirinkti grupės mokiniai.', category='error')
                return redirect(url_for('school_admin.new_group'))

        if len(group_name) > 50:
            flash('Per ilgas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_group'))
        elif len(group_name) < 1:
            flash('Per trumpas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_group'))

        new_group = NewGroup(name=group_name, students=student_ids_list, school_id=current_user.school_id)
        db.session.add(new_group)
        db.session.commit()
        return redirect(url_for('views.home'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        users_data = [{'id': user.id, 'first_last_name': user.first_last_name} for user in users]
        return render_template("new-group.html", user=current_user, users=users_data, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/groups')
@login_required
def groups():

    if current_user.urole == "SCHOOL-ADMIN":

        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        students_by_group = {}

        for group in groups:
            students = User.query.filter(User.id.in_(group.students)).all()
            students_by_group[group.id] = [student.first_last_name for student in students]

        return render_template('groups.html', groups=groups, students_by_group=students_by_group, user=current_user, school_name=user_school_name())

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/new_lesson', methods=['GET', 'POST'])
@login_required
def new_lesson():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        name = request.form.get('lessonName')
        note = request.form.get('lessonNote')
        opening_date_str = request.form.get('openingDate')
        closing_date_str = request.form.get('closingDate')
        selected_tasks_ids = request.form.get('selectedProblemId')
        selected_users_ids = request.form.get('selectedUserId')
        tasks_ids_list = list(selected_tasks_ids)
        tasks_ids_list = list(set(tasks_ids_list))
        users_ids_list = list(selected_users_ids)
        users_ids_list = list(set(users_ids_list))

        if current_user.id in users_ids_list: users_ids_list.remove(current_user.id)
        users_ids_list = [x for x in users_ids_list if x.isdigit()]
        tasks_ids_list = [x for x in tasks_ids_list if x.isdigit()]

        if opening_date_str == '': openingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')
        if closing_date_str == '': closingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

        ## Patikriname, ar teisingai pasirinkti pamokos mokiniai
        for user_id in users_ids_list:
            user = User.query.get(user_id)
            if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
                flash('Netinkamai pasirinkti pamokos mokiniai.', category='error')
                return redirect(url_for('school_admin.new_lesson'))

        ## Patikriname, ar teisingai pasirinkti pamokos užduotys
        for task_id in tasks_ids_list:
            task = Task.query.get(task_id)
            if not task or task.school_id != current_user.school_id or user.urole != "GENERAL":
                flash('Netinkamai pasirinkti pamokos uždaviniai.', category='error')
                return redirect(url_for('school_admin.new_lesson'))
            elif openingDate != defaultDate and task.openingDate != defaultDate and task.openingDate > openingDate:
                flash(f'Uždavinio „{task.name}” atidarymo data yra vėlesnė nei pamokos atidarymo data.', category='error')
                return redirect(url_for('school_admin.new_lesson'))
            elif closingDate != defaultDate and task.closingDate != defaultDate and task.closingDate < closingDate:
                flash(f'Uždavinio „{task.name}” uždarymo data yra ankstesnė nei pamokos uždarymo data.', category='error')
                return redirect(url_for('school_admin.new_lesson'))

        if len(name) > 50:
            flash('Per ilgas pamokos pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif len(name) < 1:
            flash('Per trumpas pamokos pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif len(note) > 700:
            flash('Per ilga pamokos žinutė.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif opening_date_str != '' and openingDate.year < datetime.now().year:
            flash('Netinkama pamokos atidarymo data.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif closing_date_str != '' and closingDate < datetime.now():
            flash('Netinkama pamokos uždarymo data.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif len(users_ids_list) == 0:
            flash('Būtina pasirinkti bent vieną mokinį ar grupę.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif len(tasks_ids_list) == 0:
            flash('Būtina pasirinkti bent vieną užduotį.', category='error')
            return redirect(url_for('school_admin.new_lesson'))

        new_lesson = Lessons(name=name, note=note, tasks=tasks_ids_list, openingDate=openingDate, closingDate=closingDate, students=users_ids_list,
            school_id=current_user.school_id, owner_id=current_user.id)
        db.session.add(new_lesson)
        db.session.commit()

        flash('Nauja pamoka sukurta sėkmingai.', category='success')
        return redirect(url_for('school_admin.new_lesson'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        return render_template('new-lesson.html', problems=tasks, user=current_user, users=users, groups=groups, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/lessons')
@login_required
def lessons():

    if current_user.urole == "SCHOOL-ADMIN":
        lessons = Lessons.query.filter_by(school_id=current_user.school_id).all()

        students_by_lesson = {}
        problems_by_lesson = {}

        for lesson in lessons:
            students = User.query.filter(User.id.in_(lesson.students)).all()
            student_names = [student.first_last_name for student in students]

            problems = Task.query.filter(Task.id.in_(lesson.tasks)).all()
            problem_names = [problem.name for problem in problems]

            students_by_lesson[lesson.id] = student_names
            problems_by_lesson[lesson.id] = problem_names

        return render_template('school_admin_lessons.html', lessons=lessons, students_by_lesson=students_by_lesson, problems_by_lesson=problems_by_lesson, user=current_user, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/delete_lesson/<lesson_id>', methods=['POST'])
@login_required
def delete_lesson(lesson_id):

    lock.acquire()
    lesson = Lessons.query.get(lesson_id)

    if current_user.urole == "SCHOOL-ADMIN" and lesson and lesson.owner_id == current_user.id:
        db.session.delete(lesson)
        db.session.commit()
        lock.release()
        flash('Pamoka sėkmingai ištrinta.', category='success')
        return redirect(url_for('school_admin.lessons'))
    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/student_submissions')
@login_required
def student_submissions():

    if current_user.urole == "SCHOOL-ADMIN":
        submissions = Submissions.query.join(User).filter(User.school_id == current_user.school_id, User.urole == "GENERAL").all()
        return render_template('student-submissions.html', submissions=submissions, user=current_user, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))