from email.message import EmailMessage
from email.mime.text import MIMEText
from celery import shared_task
from jinja2 import Template
import smtplib
import imghdr

### Import database ###
from . import db
from .models import User, Submissions

### Email config ###
EMAIL_ADDRESS = 'programavimoplatforma@gmail.com'
EMAIL_PASSWORD = 'qzqnzflshfupcgvu'

### HTML code paths ###
USER_SUBMISSION_HTML_PATH = '/home/platforma/WebServer/website/email_templates/user_submission.html'


@shared_task(bind=True, queue='email_sender')
def email_user_submission(self, submission_id, include_teacher=False):

	submission = Submissions.query.get(submission_id)
	user = User.query.get(submission.user_id)
	submission_date = submission.date.strftime("%Y-%m-%d %H:%M:%S")

	## Pasirenkami laiško gavėjai
	if include_teacher: contacts = [user.email]
	else: contacts = [user.email]

	## Sukuriamas laiško turinys
	msg = EmailMessage()
	msg['Subject'] = f'{submission.task.name} ({user.first_last_name})'
	msg['From'] = EMAIL_ADDRESS
	msg['To'] = contacts

	# Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
	with open(USER_SUBMISSION_HTML_PATH, 'r') as html_code:
		html_content = html_code.read()

	data = {
		'user_name': user.first_last_name,
		'submission_date': submission_date,
		'task_name': submission.task.name,
		'score': str(submission.score),
		'test_count': str(submission.task.problems.testCount),
		'submission_id': submission.id
	}

	template = Template(html_content)
	rendered_html = template.render(data)

	msg.add_alternative(rendered_html, subtype='html')

	## Pridedamas vartotojo pateiktas sprendimas
	cpp_attachment = MIMEText(submission.submitted_code, 'plain')
	cpp_attachment.add_header('Content-Disposition', 'attachment', filename=f'{submission.task.name}.cpp')
	msg.attach(cpp_attachment)

	## El. laiškas išsiunčiamas gavėjui/gavėjams
	with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
		smtp.ehlo()
		smtp.starttls()
		smtp.ehlo()
		smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
		smtp.send_message(msg)

	return