from celery import shared_task
from queue import Queue
import os
import sys
from . import db
from .models import Submissions
from .email_sender import email_user_submission

### Testing enviroments config ###
for env_id in range(1, 6):
    sys.path.append(f'/home/vilius/Desktop/Server/Testavimo_aplinka/Aplinka{env_id}')

### Importing testing enviroment directories ###
from kompiliatorius1 import Aplinka1
from kompiliatorius2 import Aplinka2
from kompiliatorius3 import Aplinka3
from kompiliatorius4 import Aplinka4
from kompiliatorius5 import Aplinka5

Testing_Environments = {
    1: Aplinka1,
    2: Aplinka2,
    3: Aplinka3,
    4: Aplinka4,
    5: Aplinka5
}

### Queues and sets ###
Submitted_code_set = set()
Availible_testing_environment = Queue()
for env_number in range(1, 6): Availible_testing_environment.put(env_number)

@shared_task(bind=True, queue='submitted_file_queue')
def compile_code(self, user_id, problem_id, task_id, time_limit, memory_limit, test_count, submitted_code, open_test_cases):

    submission = Submissions.query.filter_by(celery_id=self.request.id).first()

    ## Laukiame, kol vartotojo sprendimas atsiras databazėje
    while not submission:
        submission = Submissions.query.filter_by(celery_id=self.request.id).first()

    ## Pakeičiamas vartotojo pateikto sprendimo statusas ##
    if (user_id, problem_id) in Submitted_code_set:
        submission.status = -1
        db.session.commit()
        return
    else:
        submission.status = 0
        db.session.commit()

    ## Vartotojo pateiktas sprendimas testuojamas ##
    results = []

    Submitted_code_set.add((user_id, problem_id))
    Environment_id = Availible_testing_environment.get()

    ## Vartotojo pateiktas kodas paverčiamas į cpp programą
    file_path = f'/home/vilius/Desktop/Server/Testavimo_aplinka/Aplinka{Environment_id}/programa.cpp'

    if os.path.exists(file_path):
        try: os.remove(file_path)
        except:
            Submitted_code_set.remove((user_id, problem_id))
            Availible_testing_environment.put(Environment_id)
            submission.status = 1
            db.session.commit()
            return

    with open(file_path, 'w') as f:
        f.write(submitted_code)

    ## Failas sukompiliuojamas ir paleidžiamas
    try:
        results, status, score, error_msg, output = Testing_Environments[Environment_id](test_count, memory_limit, time_limit, problem_id, open_test_cases)
    except:

        Submitted_code_set.remove((user_id, problem_id))
        Availible_testing_environment.put(Environment_id)
        submission.status = 1
        db.session.commit()
        return

    ## Testavimo aplinka pridedama prie laisvu aplinku saraso
    Submitted_code_set.remove((user_id, problem_id))
    Availible_testing_environment.put(Environment_id)

    ## Į databazę įkeliame testavimo rezultatus
    submission.status = status
    submission.score = score
    submission.results = results
    submission.error_msg = error_msg
    submission.output = output
    db.session.commit()

    ## Varotojui išsiunčiamas el. laiškas
    email_user_submission.delay(submission_id=submission.id)

    ## Pabaigiame programos testavima
    return