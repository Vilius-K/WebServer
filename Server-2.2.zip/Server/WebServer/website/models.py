from . import db
from flask_login import UserMixin
from sqlalchemy import DateTime
from sqlalchemy_jsonfield import JSONField
from datetime import datetime
from sqlalchemy.sql import func
import datetime
import pytz

timezone = pytz.timezone('Europe/Vilnius')

class Problems(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    timeLimit = db.Column(db.Integer, default=1)
    memoryLimit = db.Column(db.Integer, default=64)
    testCount = db.Column(db.Integer)
    school_id = db.Column(db.Integer)
    custom_tester = db.Column(db.Boolean, default=False)
    task = db.relationship('Task', backref='problems', lazy=True)

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    problemsId = db.Column(db.Integer, db.ForeignKey('problems.id'))
    name = db.Column(db.String(100))
    openingDate = db.Column(DateTime, default=lambda: datetime.datetime.now(timezone))
    closingDate = db.Column(DateTime, default=lambda: datetime.datetime.now(timezone))
    school_id = db.Column(db.Integer)
    date = db.Column(db.DateTime(timezone=True), default=lambda: datetime.datetime.now(timezone))
    testingDate = db.Column(db.DateTime(timezone=True))
    open_test_cases = db.Column(db.Integer, default=0)
    groups = db.Column(JSONField)
    submissions = db.relationship('Submissions', backref='task', lazy=True)

class School(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    owner_id = db.Column(db.Integer)
    problem_limit = db.Column(db.Integer)
    task_limit = db.Column(db.Integer)
    created_problems = db.Column(db.Integer, default=0)
    created_tasks = db.Column(db.Integer, default=0)
    invitation_code = db.Column(db.String(100), unique=True)
    availible_until = db.Column(DateTime)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_last_name = db.Column(db.String(41))
    urole = db.Column(db.String(20), default='GENERAL')
    school_id = db.Column(db.Integer, default=0)
    submissions = db.relationship('Submissions', backref='user', lazy=True)


### Vartotojų pateikti sprendimai ###
## Pateiktas sprendimas turi šiuos statusus: ##
# -3 - pateiktas sprendimas laukia eilėje
# -2 - testavimas bus atliktas nustatytu metu
# -1 - testavimas atšauktas, nes testuojamas kitas pateiktas kodas
#  0 - pateiktas kodas šiuo metu testuojamas
#  1 - testavimas baigtas, testavimo metu atsirado nenumatyta klaida
#  2 - testavimas baigtas, pateiktas kodas nesikompiliuoja
#  3 - testavimas baigtas, pateiktas kodas kompiliuojasi

### Pateikto sprendimo rezultatai ###
## Pateikto sprendimo rezultatai turi šias reikšmes: ##
#  1 - testavimo metu viršytas laiko limitas
#  2 - testavimo metu viršytas atminties limitas
#  3 - pateiktas rezultatas tinka
#  4 - pateiktas rezultatas netinka
#  5 - dalinio testavimo metu atsirado nenumatyta klaida

class Submissions(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'))
    celery_id = db.Column(db.String(200))
    status = db.Column(db.Integer) ## Pateikto sprendimo statusas
    results = db.Column(JSONField) ## Pateikto sprendimo rezultatai
    output = db.Column(JSONField) ## Programos spausdinami rezultatai
    score = db.Column(db.Integer, default=0)  ## Pateikto sprendimo įvertinimas
    error_msg = db.Column(db.String(300))
    submitted_code = db.Column(db.String(560000))
    date = db.Column(db.DateTime(timezone=True), default=lambda: datetime.datetime.now(timezone))

class NewGroup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer)
    name = db.Column(db.String(100))
    students = db.Column(JSONField)


class Lessons(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer)
    name = db.Column(db.String(100))
    note = db.Column(db.String(700))
    school_id = db.Column(db.Integer)
    students = db.Column(JSONField)
    tasks = db.Column(JSONField)
    openingDate = db.Column(DateTime, default=lambda: datetime.datetime.now(timezone))
    closingDate = db.Column(DateTime, default=lambda: datetime.datetime.now(timezone))