from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for
from flask_login import login_required, current_user
from .models import User, School
from datetime import datetime
from . import db
import random, string


### Blueprint config ###
admin = Blueprint('admin', __name__)


def user_school_name():
    if current_user.school_id != 0: return School.query.get(current_user.school_id).name
    else: return ''


@admin.route('/admin/users')
@login_required
def users():

    if current_user.urole == "SERVER-ADMIN":
        return render_template("users.html", user=current_user, user_list=User.query.all(), school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))


@admin.route('/admin/delete_user', methods = ['POST'])
@login_required
def delete_user():

    delete_user_id = request.form.get('user_id')
    delete_user = User.query.get(delete_user_id)

    if current_user.urole == "SERVER-ADMIN" and delete_user:
        db.session.delete(delete_user)
        db.session.commit
        return redirect(url_for('admin.users'))
    else:
        return redirect(url_for('views.home'))


@admin.route('/admin/users/<user_id>', methods=['GET', 'POST'])
@login_required
def user(user_id):

    user = User.query.get(user_id)

    if current_user.urole == "SERVER-ADMIN" and request.method == 'POST' and user:

        user.email = request.form.get('email')
        user.first_last_name = request.form.get('first_last_name')

        school_id = request.form.get('school_id')
        school = School.query.get(int(school_id))

        if int(school_id) != 0 and not school:
            flash('Pasirinkta mokykla neegzistuoja.', category='error')
            return redirect(url_for('admin.user'))

        user.school_id = request.form.get('school_id')
        user.urole = request.form.get('urole')
        db.session.commit()
        return redirect(url_for('admin.users'))

    elif current_user.urole == "SERVER-ADMIN" and request.method == 'GET' and user:
        school_name = user_school_name()
        return render_template("user.html", user=current_user, editing_user=user, school_name=school_name)
    else:
        return redirect(url_for('views.home'))


@admin.route('/admin/schools')
@login_required
def schools():

    if current_user.urole == "SERVER-ADMIN":
        return render_template("schools.html", user=current_user, school_list=School.query.all(), school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))


@admin.route('/admin/schools/<school_id>', methods=['GET', 'POST'])
@login_required
def school(school_id):

    school = School.query.get(school_id)

    if current_user.urole == "SERVER-ADMIN" and request.method == 'POST' and school:

        owner_id = request.form.get('owner_id')
        school_name = request.form.get('name')
        owner = User.query.get(int(owner_id))
        problem_limit = request.form.get('problem_limit')
        task_limit = request.form.get('task_limit')

        if not owner:
            flash('Pasirinktas mokyklos administratorius neegzistuoja.', category='error')
            return redirect(url_for('admin.school'))
        elif len(school_name) > 100:
            flash('Per ilgas mokyklos pavadinimas.', category='error')
            return redirect(url_for('admin.school'))


        school.owner_id = int(owner_id)
        school.name = school_name
        school.problem_limit = int(problem_limit)
        school.task_limit = int(task_limit)
        school.invitation_code = request.form.get('invitation_code')
        db.session.commit()
        return redirect(url_for('admin.schools'))

    elif current_user.urole == "SERVER-ADMIN" and request.method == 'GET' and school:
        return render_template("school.html", user=current_user, school=school, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))


@admin.route('/admin/delete_school', methods = ['POST'])
@login_required
def delete_school():
    delete_school_id = request.form.get('school_id')
    delete_school = School.query.get(delete_school_id)
    if current_user.urole == "SERVER-ADMIN" and delete_school:
        db.session.delete(delete_school)
        db.session.commit()
        return redirect(url_for('admin.schools'))
    else:
        return redirect(url_for('views.home'))


@admin.route('/admin/new-school', methods=['GET', 'POST'])
@login_required
def new_school():

    if request.method == 'POST' and current_user.urole == "SERVER-ADMIN":
        
        ## Reikiama informacija apie naują mokyklą
        school_name = request.form.get('school_name')
        problem_limit = request.form.get('problem_limit')
        task_limit = request.form.get('task_limit')
        owner_id = request.form.get('owner_id')
        availible_until_str = request.form.get('availible_until')
        
        if availible_until_str != '': availible_until = datetime.strptime(availible_until_str, '%Y-%m-%dT%H:%M')
        else: availible_until = datetime(1111, 1, 1, 11, 11, 11)

        ## Patikriname, ar egzistuoja norimas mokyklos administratorius
        owner = User.query.get(owner_id)
        if not owner:
            flash('Pasirinktas mokyklos administratorius neegzistuoja.', category='error')
            return redirect(url_for('admin.new_school'))

        if int(task_limit) < 1 or int(problem_limit) < 1:
            flash('Netinkamai nustatyti limitai.', category='error')
            return redirect(url_for('admin.new_school'))

        if len(school_name) > 100:
            flash('Per ilgas mokyklos pavadinimas.', category='error')
            return redirect(url_for('admin.new_school'))


        ## Sukuriame mokyklos pakvietimo kodą
        letters = string.ascii_lowercase
        invitation_code = ''.join(random.choice(letters) for i in range(10))
        while School.query.filter_by(invitation_code=invitation_code).first():
            invitation_code = ''.join(random.choice(letters) for i in range(10))

        ## Į databazę įkeliame informaciją apie naują mokyklą
        new_school = School(name=school_name, problem_limit=problem_limit, task_limit=task_limit, owner_id=owner_id, availible_until=availible_until,
            invitation_code=invitation_code)
        db.session.add(new_school)
        db.session.commit()

        flash('Nauja mokykla sukurta sėkmingai.', category='success')
        return redirect(url_for('views.home'))

    elif request.method == 'GET' and current_user.urole == "SERVER-ADMIN":
        return render_template("new-school.html", user=current_user, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))