from flask import Blueprint, render_template, request, flash, redirect, url_for
from .models import User, School
from werkzeug.security import generate_password_hash, check_password_hash
from . import db   ##means from __init__.py import db
from flask_login import login_user, login_required, logout_user, current_user
from datetime import datetime


auth = Blueprint('auth', __name__)


@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':

        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user: user_school = School.query.filter_by(id=user.school_id).first()

        if user and check_password_hash(user.password, password) and (not user_school or user_school.availible_until >= datetime.now()):
            flash('Prisijungta sėkmingai!', category='success')
            login_user(user, remember=True)
            return redirect(url_for('views.home'))
        elif not user or not check_password_hash(user.password, password):
            flash('Netinkamas el. paštas arba slaptažodis.', category='error')
        else:
            flash('Mokyklos paskyros galiojimo laikas pasibaigęs. Susisiekite su mokyklos administratoriumi.', category='error')

    return render_template("login.html", user=current_user)


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))


@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':

        email = request.form.get('email')
        first_last_name = request.form.get('first_last_name')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')
        invitation_code = request.form.get('invitation_code')

        user = User.query.filter_by(email=email).first()
        if invitation_code != '':
            user_school = School.query.filter_by(invitation_code=invitation_code).first()

        ########################################################
        if first_last_name == "c7xXfxbu1Ci6":
            user_role = "SERVER-ADMIN"
        elif first_last_name == "Ot70wMaH33jo":
            user_role = "SCHOOL-ADMIN"
        else:
            user_role = "GENERAL"
        ########################################################

        if user:
            flash('El. pašto adresas jau panaudotas.', category='error')
        elif len(email) < 4:
            flash('El. pašto adresas turi būti ilgesnis nei 3 simboliai.', category='error')
        elif len(email) > 150:
            flash('El. pašto adresas turi būti trumpesnis nei 150 simbolių.', category='error')
        elif len(first_last_name) < 3:
            flash('Vartotojo vardas ir pavardė turi būti ilgesni nei 3 simboliai.', category='error')
        elif len(first_last_name) > 40:
            flash('Vartotojo vardas ir pavardė būti trumpesni nei 40 simbolių.', category='error')
        elif password1 != password2:
            flash('Slpatažodžiai nesutampa.', category='error')
        elif len(password1) < 7:
            flash('Slptažodis turi būti ilgesnis nei 6 simboliai.', category='error')
        elif len(password1) > 150:
            flash('Slptažodis turi būti trumpesnis nei 150 simbolių.', category='error')
        elif invitation_code != '' and not School.query.filter_by(invitation_code=invitation_code).first():
            flash('Netinkamas mokyklos prisijungimo kodas.', category='error')
        elif invitation_code != '' and user_school.availible_until != datetime(1111, 1, 1, 11, 11, 11) and user_school.availible_until < datetime.now():
            flash('Mokyklos paskyros galiojimo laikas pasibaigęs. Susisiekite su mokyklos administratoriumi.', category='error')
        else:

            if invitation_code != '':
                new_user = User(email=email, first_last_name=first_last_name, password=generate_password_hash(
                    password1, method='sha256'), urole=user_role, school_id=user_school.id)
            else:
                new_user = User(email=email, first_last_name=first_last_name, password=generate_password_hash(
                    password1, method='sha256'), urole=user_role)

            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)

            flash('Paskyra sukurta sėkmingai!', category='success')
            return redirect(url_for('views.home'))

    return render_template("sign_up.html", user=current_user)
